package org.opensearch.security.cedarling.service;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.opensearch.security.cedarling.model.AuthZenEvaluationRequest;
import org.opensearch.security.cedarling.model.AuthZenEvaluationResponse;
import org.opensearch.common.logging.Logger;
import org.opensearch.common.logging.Loggers;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.io.IOException;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

/**
 * Authentic Cedarling client that integrates with real jans-cedarling service
 * Uses AuthZen evaluation endpoints and well-known configuration
 */
public class AuthenticCedarlingClient {
    
    private static final Logger logger = Loggers.getLogger(AuthenticCedarlingClient.class);
    
    private final String cedarlingBaseUrl;
    private final CloseableHttpClient httpClient;
    private final ObjectMapper objectMapper;
    private final int timeoutMs;
    
    public AuthenticCedarlingClient(String cedarlingBaseUrl, int timeoutMs) {
        this.cedarlingBaseUrl = cedarlingBaseUrl.endsWith("/") ? 
            cedarlingBaseUrl.substring(0, cedarlingBaseUrl.length() - 1) : cedarlingBaseUrl;
        this.timeoutMs = timeoutMs;
        this.httpClient = HttpClients.createDefault();
        this.objectMapper = new ObjectMapper();
    }
    
    /**
     * Get well-known AuthZen configuration from authentic Cedarling service
     */
    public CompletableFuture<Map<String, Object>> getWellKnownConfiguration() {
        return CompletableFuture.supplyAsync(() -> {
            try {
                String url = cedarlingBaseUrl + "/.well-known/authzen-configuration";
                HttpGet httpGet = new HttpGet(url);
                httpGet.setHeader("Accept", "application/json");
                
                try (CloseableHttpResponse response = httpClient.execute(httpGet)) {
                    String responseBody = EntityUtils.toString(response.getEntity());
                    
                    if (response.getStatusLine().getStatusCode() == 200) {
                        return objectMapper.readValue(responseBody, Map.class);
                    } else {
                        logger.warn("Failed to get well-known configuration: status={}, body={}", 
                                   response.getStatusLine().getStatusCode(), responseBody);
                        return null;
                    }
                }
            } catch (Exception e) {
                logger.error("Error getting well-known configuration", e);
                return null;
            }
        }).orTimeout(timeoutMs, TimeUnit.MILLISECONDS);
    }
    
    /**
     * Evaluate authorization using authentic Cedarling AuthZen endpoint
     */
    public CompletableFuture<AuthZenEvaluationResponse> evaluate(AuthZenEvaluationRequest request) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                String url = cedarlingBaseUrl + "/cedarling/evaluation";
                HttpPost httpPost = new HttpPost(url);
                
                String requestBody = objectMapper.writeValueAsString(request);
                httpPost.setEntity(new StringEntity(requestBody, "UTF-8"));
                httpPost.setHeader("Content-Type", "application/json");
                httpPost.setHeader("Accept", "application/json");
                
                try (CloseableHttpResponse response = httpClient.execute(httpPost)) {
                    String responseBody = EntityUtils.toString(response.getEntity());
                    
                    if (response.getStatusLine().getStatusCode() == 200) {
                        return objectMapper.readValue(responseBody, AuthZenEvaluationResponse.class);
                    } else {
                        logger.warn("AuthZen evaluation failed: status={}, body={}", 
                                   response.getStatusLine().getStatusCode(), responseBody);
                        return new AuthZenEvaluationResponse(false, Map.of("error", "Evaluation failed"));
                    }
                }
            } catch (Exception e) {
                logger.error("Error during AuthZen evaluation", e);
                return new AuthZenEvaluationResponse(false, Map.of("error", e.getMessage()));
            }
        }).orTimeout(timeoutMs, TimeUnit.MILLISECONDS);
    }
    
    /**
     * Check if authentic Cedarling service is available
     */
    public CompletableFuture<Boolean> checkServiceHealth() {
        return CompletableFuture.supplyAsync(() -> {
            try {
                String url = cedarlingBaseUrl + "/.well-known/authzen-configuration";
                HttpGet httpGet = new HttpGet(url);
                httpGet.setHeader("Accept", "application/json");
                
                try (CloseableHttpResponse response = httpClient.execute(httpGet)) {
                    return response.getStatusLine().getStatusCode() == 200;
                }
            } catch (Exception e) {
                logger.debug("Cedarling service health check failed", e);
                return false;
            }
        }).orTimeout(timeoutMs, TimeUnit.MILLISECONDS);
    }
    
    /**
     * Get policy store metadata from authentic Cedarling service
     */
    public CompletableFuture<Map<String, Object>> getPolicyStoreMetadata() {
        return CompletableFuture.supplyAsync(() -> {
            try {
                // Use a custom endpoint for policy store metadata
                String url = cedarlingBaseUrl + "/cedarling/policy-store/metadata";
                HttpGet httpGet = new HttpGet(url);
                httpGet.setHeader("Accept", "application/json");
                
                try (CloseableHttpResponse response = httpClient.execute(httpGet)) {
                    String responseBody = EntityUtils.toString(response.getEntity());
                    
                    if (response.getStatusLine().getStatusCode() == 200) {
                        return objectMapper.readValue(responseBody, Map.class);
                    } else {
                        logger.debug("Policy store metadata not available: status={}", 
                                    response.getStatusLine().getStatusCode());
                        return Map.of("status", "unavailable");
                    }
                }
            } catch (Exception e) {
                logger.debug("Error getting policy store metadata", e);
                return Map.of("status", "error", "message", e.getMessage());
            }
        }).orTimeout(timeoutMs, TimeUnit.MILLISECONDS);
    }
    
    public void close() {
        try {
            httpClient.close();
        } catch (IOException e) {
            logger.warn("Error closing HTTP client", e);
        }
    }
}